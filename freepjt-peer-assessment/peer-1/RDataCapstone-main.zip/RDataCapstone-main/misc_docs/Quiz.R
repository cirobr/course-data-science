##### Q1 #####
nrow(edx)
ncol(edx)

##### Q2 #####
table(edx$rating == 0)
table(edx$rating == 3)

##### Q3 #####
length(unique(edx$movieId))

##### Q4 #####
length(unique(edx$userId))

##### Q5 #####
sum(str_detect(edx$genres, "Drama"))
sum(str_detect(edx$genres, "Comedy"))
sum(str_detect(edx$genres, "Thriller"))
sum(str_detect(edx$genres, "Romance"))

##### Q6 #####
print("Forrest Gump"); sum(str_detect(edx$title, "Forrest Gump"))
print("Jurassic Park"); sum(str_detect(edx$title, "Jurassic Park"))
print("Pulp Fiction"); sum(str_detect(edx$title, "Pulp Fiction"))
print("Shawshank Redemption"); sum(str_detect(edx$title, "Shawshank Redemption"))
print("Speed 2"); sum(str_detect(edx$title, "Speed 2"))

edx %>% group_by(movieId, title) %>%
  summarize(count = n()) %>%
  arrange(desc(count))

##### Q7 #####
sort(table(edx$rating), decreasing = T)
