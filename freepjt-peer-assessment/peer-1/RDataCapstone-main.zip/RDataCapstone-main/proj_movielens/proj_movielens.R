#### Baseline Setup: Libraries and Data loading ####

needed.packages <- c("tidyverse", "caret", "data.table")
for(pack in needed.packages){
  if(pack %in% rownames(installed.packages()) == FALSE)
  {install.packages(pack)}
}
rm(needed.packages)

library(tidyverse)
library(caret)
library(data.table)
# switch this for your machine, you will not have the same file structure as I:
setwd("E:/Projektvault/Coding/RDataCapstone/proj_movielens")

### Data Loading and validation split: Code copied from setup instructions
{
  # skip all this if you already prepared it on your own
  dl <- tempfile()
  download.file("http://files.grouplens.org/datasets/movielens/ml-10m.zip", dl)
  
  ratings <- fread(text = gsub("::", "\t", readLines(unzip(dl, "ml-10M100K/ratings.dat"))),
                   col.names = c("userId", "movieId", "rating", "timestamp"))
  movies <- str_split_fixed(readLines(unzip(dl, "ml-10M100K/movies.dat")), "\\::", 3)
  colnames(movies) <- c("movieId", "title", "genres")
  
  movies <- as.data.frame(movies) %>% mutate(movieId = as.numeric(movieId),
                                             title = as.character(title),
                                             genres = as.character(genres))
  movielens <- left_join(ratings, movies, by = "movieId")
  
  set.seed(1, sample.kind="Rounding")
  test_index <- createDataPartition(y = movielens$rating, times = 1, p = 0.1, list = FALSE)
  edx <- movielens[-test_index,]
  temp <- movielens[test_index,]
  
  validation <- temp %>% 
    semi_join(edx, by = "movieId") %>%
    semi_join(edx, by = "userId")
  
  removed <- anti_join(temp, validation)
  edx <- rbind(edx, removed)
  
  rm(dl, ratings, movies, test_index, temp, movielens, removed)
}

### Optional: Save/Load for easy use and reuse
movielens <- read.csv("data/movielens_compl.csv")
write.csv(edx, file = "data/edx_set.csv")
write.csv(validation, file = "data/validation_set.csv")
## saves with row number as col. 1, so drop col. 1 on reload, like this:
# edx <- read.csv("data/edx_set.csv")[, 2:7]
# validation <- read.csv("data/validation_set.csv")[, 2:7]



#### Project setup: Split Edx data into test/train sets ####

edx <- read.csv("data/edx_set.csv")[, 2:7]
set.seed(2002) # I trust in everyone to have at least R 3.6 by now - otherwise, what are you doing? Seriously.
test_index <- createDataPartition(y = edx$rating, times = 1, p = 0.15, 
                                  list = FALSE) # split off 15% of edx-dataset as test set
edx_train <- edx[-test_index,]
temp <- edx[test_index,]
# ensure all users/movies are represented in both sets
edx_test <- temp %>% 
  semi_join(edx_train, by = "movieId") %>%
  semi_join(edx_train, by = "userId")
# Add removed rows back in, as to not accidentally discard certain rows
removed <- anti_join(temp, edx_test)
edx_train <- rbind(edx_train, removed)

nrow(edx_train) + nrow(edx_test) == nrow(edx) # check for missing/extra rows (would imply errors in code)
rm(test_index, temp, removed); gc() # environment cleanup to free unused RAM from deleted large data sets


#### Baseline RMSEA (to-beat values) ####

# using mean over all ratings as prediction for all ratings
globAvg <- mean(edx_train$rating) # not as methodologically accurate as the mu_hat naming convention, but easier to follow imo
rmse_naive <- RMSE(edx_test$rating, globAvg)

rmse_results <- tibble(method = "to-beat value", RMSE = 0.86490) # ideal score for perfect grade (=25 points in RMSE category)
rmse_results <- bind_rows(rmse_results, tibble(method = "naive avg.", RMSE = rmse_naive)) # worst-case prediction
rmse_results

rm(rmse_naive)


#### Movie Effects ####

# Idea: create a data frame of all individual movies to ease data overview and calculations, and calculate movie-based effects for prediction
# compute average rating for each individual movie (= deviation from global mean, as global mean is baseline predictor)
movie_avgs <- edx_train %>% 
  group_by(movieId) %>% 
  summarize(movieAvg = mean(rating - globAvg))

# compute N of ratings for each movie, to counteract low-N biases
movie_N <- edx_train %>% 
  group_by(movieId) %>% 
  count(movieId)

# merge data into global movie database
mov_df <- unique(edx_train[,c(2,5)]) # select movieID and movie name column from original data
mov_df <- mov_df %>% left_join(movie_avgs, by='movieId')
mov_df <- mov_df %>% left_join(movie_N, by='movieId')

# calculate improvement: predict global and movie avg instead of only global avg
mov_pred <- globAvg + edx_test %>% 
  left_join(mov_df, by = "movieId") %>% pull(movieAvg)
# join to sync up ratings to movie order, then pull movie ratings
rmse_mov <- RMSE(mov_pred, edx_test$rating)
rmse_results <- bind_rows(rmse_results, tibble(method = "+ movie effect", RMSE = rmse_mov)) # movie-based prediction
rmse_results # pretty decent improvement already

rm(movie_N, movie_avgs, mov_pred, rmse_mov); gc()



#### Movie Regularization ####

# Penalize movies with low amounts of ratings, as they are more dependent on individual ratings, i.e. possible outlier-evaluations

# Finding lambda (penalty tuning parameter)
lambdas_m <- seq(0, 5, 0.25) # parameter estimates
sum_list_m <- edx_train %>% 
  group_by(movieId) %>% 
  summarize(reviewSum = sum(rating - globAvg), reviewN = n())
# data frame of amounts of ratings and differences to mean summed per movie
rmses_m <- sapply(lambdas_m, function(l){
  predicted_ratings <- edx_test %>% 
    left_join(sum_list_m, by='movieId') %>% # introduce calculated data
    mutate(regAvg = reviewSum/(reviewN+l)) %>% # reform mean with selected penalty term
    mutate(pred = globAvg + regAvg) %>%
    pull(pred)
  RMSE(predicted_ratings, edx_test$rating) # calculate prediction
})
qplot(lambdas_m, rmses_m)
lam_m <- lambdas_m[which.min(rmses_m)]

# Calculate regularized averages for each movie:
movie_avgs_reg <- edx_train %>% 
  group_by(movieId) %>% 
  summarize(movieAvgReg = sum(rating - globAvg)/(n()+lam_m))
# Merge into movie database
mov_df <- mov_df %>% left_join(movie_avgs_reg, by='movieId')

# calculate improvement
mov_pred_reg <- globAvg + edx_test %>% 
  left_join(mov_df, by = "movieId") %>% pull(movieAvgReg)
# join to sync up ratings to movie order, then pull movie ratings
rmse_mov_reg <- RMSE(mov_pred_reg, edx_test$rating)
rmse_results <- bind_rows(rmse_results, tibble(method = "movie regularization", RMSE = rmse_mov_reg)) # movie-based prediction
rmse_results
print.data.frame(rmse_results) # printing as data frame shows more decimal places - looks less nice than tibble though
# We achieve an improvement in the RMSE-values, but it is rather minimal compared to the previous improvement - This is probably down to the fact that, with 10m cases, even the (in relation to other movies) lower amounts of ratings are enough to counterbalance possible outliers

rm(lambdas_m, rmses_m, sum_list_m, movie_avgs_reg, mov_pred_reg, rmse_mov_reg)



#### User effects ####

# Same as above, but for user effects this time - so, remaining rating mean after global and movie means are subtracted

user_avgs <- edx_train %>% 
  left_join(mov_df, by='movieId') %>%
  group_by(userId) %>% 
  summarize(userAvg = mean(rating - globAvg - movieAvg))

# compute N of ratings for each user, for potential timeline filter based on N of ratings
user_N <- edx_train %>% 
  group_by(userId) %>% 
  count(userId)

# merge data into global user database
usr_df <- user_avgs %>% left_join(user_N, by='userId')

# calculate improvement: predict with movie avg and user avg instead of only global avg
usr_pred <- globAvg + 
  edx_test %>% left_join(mov_df, by = "movieId") %>% pull(movieAvgReg) +
  edx_test %>% left_join(usr_df, by = "userId") %>% pull(userAvg)
# join used here to sync up user/movie based score modifiers to given movie order in the validation file
rmse_usr <- RMSE(usr_pred, edx_test$rating)
rmse_results <- bind_rows(rmse_results, tibble(method = "+ user effect", RMSE = rmse_usr)) # user-based prediction
rmse_results # again, a pretty decent improvement

rm(usr_pred, user_avgs, user_N, rmse_usr)



#### User Regularization ####

# As above, penalize Users with low amounts of ratings, as individual movie ratings may obscure the general user bias
# Finding lambda (penalty tuning parameter)
lambdas_u <- seq(0, 15, 0.25) # parameter estimates
sum_list_u <- edx_train %>% 
  left_join(mov_df, by='movieId') %>%
  group_by(userId) %>% 
  summarize(reviewSum = sum(rating - globAvg - movieAvgReg), reviewN = n())
# data frame of amounts of ratings and differences to mean summed per user

rmses_u <- sapply(lambdas_u, function(l){
  predicted_ratings <- edx_test %>% 
    left_join(sum_list_u, by='userId') %>% # introduce calculated data
    mutate(regAvg = reviewSum/(reviewN+l)) %>% # reform mean with selected penalty term
    mutate(pred = globAvg + regAvg) %>%
    pull(pred)
  RMSE(predicted_ratings, edx_test$rating) # calculate prediction
})
qplot(lambdas_u, rmses_u)
lam_u <- lambdas_u[which.min(rmses_u)]

# Calculate regularized averages for each user:
user_avgs_reg <- edx_train %>% 
  left_join(mov_df, by='movieId') %>%
  group_by(userId) %>% 
  summarize(userAvgReg = sum(rating - globAvg - movieAvgReg)/(n()+lam_u))
# Merge into movie database
usr_df <- usr_df %>% left_join(user_avgs_reg, by='userId')

# calculate improvement
usr_pred_reg <- globAvg + 
  edx_test %>% left_join(mov_df, by = "movieId") %>% pull(movieAvgReg) + 
  edx_test %>% left_join(usr_df, by = "userId") %>% pull(userAvgReg)

rmse_usr_reg <- RMSE(usr_pred_reg, edx_test$rating)
rmse_results <- bind_rows(rmse_results, tibble(method = "user regularization", RMSE = rmse_usr_reg))
rmse_results
print.data.frame(rmse_results)
# Again a pretty small improvement, but more noticeable than movie regularization was - probably because we have way more users than movies and therefore more users with low amounts of reviews compared to movie review numbers
rm(sum_list_u, user_avgs_reg, lambdas_u, rmse_usr_reg, rmses_u, usr_pred_reg)



#### Prediction on validation set based on regularized movie and user effects ####

# To get a feeling of where we're at with our predictions, why not validate this baseline model of mu + b_movie(regularized) + b_user(regularized)? This will: 
# a) show us the normalizing effect of our bigger data set, as in the course with less data the (unregularized) RMSE at this point was ~0.905 and
# b) show us how big the remaining improvements still have to be to undercut the given target of RMSE < 0.86490
rm(edx_test, edx_train); gc() # free memory as we are now working with the entire edx and validation sets

# step 1: recalculate predictors (means per movie/user) based on entire edx-set
edx <- read.csv("data/edx_set.csv")[, 2:7]
validation <- read.csv("data/validation_set.csv")[, 2:7]

mu <- mean(edx$rating)

edx_b_m <- edx %>% group_by(movieId) %>% # m for movie effect
  summarize(b_m = sum(rating - mu) / (n() + lam_m)) # with regularization calculated in edx set
edx_b_u <- edx %>% # u for user effect
  left_join(edx_b_m, by='movieId') %>% group_by(userId) %>% 
  summarize(b_u = sum(rating - mu - b_m) / (n() + lam_u)) # with regularization calculated in edx set
# Regularization parameters (lambdas) are not recalculated on the entire edx set as that would require using the validation result before the final evaluation. This would a) ruin our blind prediction and b) potentially manipulate our results by overfitting on validation set features

# step 2: prediction on validation set
edx_pred <- mu + 
  validation %>% left_join(edx_b_m, by = "movieId") %>% pull(b_m) +
  validation %>% left_join(edx_b_u, by = "userId") %>% pull(b_u)

RMSE(edx_pred, validation$rating)
RMSE(edx_pred, validation$rating) - 0.86490 # given target value for 25 points (see grading guidelines)
# we are already under our given goal with these two baseline predictors and their respective regularization, therefore, no further steps are needed
rm(mu, edx, edx_b_m, edx_b_u, edx_pred, validation)
gc()
