# RDataCapstone
All the code written for the final exam in Harvard's EDX Data Science course (https://www.edx.org/professional-certificate/harvardx-data-science)
The final exam encompasses two exercises:
- Building a prediction algorithm for movie reviews on a given data set  
- Building a machine learning algorithm to solve a problem of one's own choice  

For both tasks, this repo includes the R code, along with the report R-Markdown file and the resulting PDF from knitting said file.

### MovieLens movie prediction algorithm
Found in the proj_movielens subfolder, this project was started with the intention of using as few predictors that are as easy as possible to reach the requested prediction quality (measured via RMSE).

### Topics of popular IRA tweets
Found in the proj_cyo subfolder and based on my bachelor's thesis (see https://github.com/fallenEngels/TwitterBachelor), this work is based on a subset of far-reaching IRA tweets. With the help of machine learning, and especially Natural Language Processing methodology, I analyzed topic structures in the most widely shared IRA tweets to see which contents, ressentiments and accounts managed to achieve popularity on Twitter.
